#############################################################
This is a placeholder README.
If you are the author, please fill in the __sections__ below.
If you are not the author, please bug the author.
#############################################################

## __PLUGINNAME__, a plugin for Movable Type
## Author: __AUTHORNAME__, __EMAIL/URL__
## Version: __VERSION__
## Released under __LICENSE__
##
## $Id$
 
## OVERVIEW ##

__A short and very basic description of the plugin.__

## PREREQUISITES ##

__detail MT version compatibility and anything else the plugin requires__

## FEATURES ##

__A longer description of the plugin's features for those who are still reading__

## INSTALLATION ##

__detail installation instructions__

## CONFIGURATION ##

__detail configuration instructions, if any__

## USAGE ##

__detail further usage instructions, if any__

## KNOWN ISSUES ##

__detail any known issues with current version, if any__

## SUPPORT ##

__specify where people can go for support__

## SOURCE CODE ##

Source

SVN Repo:
    http://code.sixapart.com/svn/mtplugins/trunk/__PLUGINNAME__

Trac View:
    http://code.sixapart.com/trac/mtplugins/log/trunk/__PLUGINNAME_

Plugins:
    http://plugins.movabletype.org/__PLUGIN__


## LICENSE ##

__specify the license the plugin is released under__

## AUTHOR ##

__insert arbitrary author info, e.g name, email, URL, company, etc__
