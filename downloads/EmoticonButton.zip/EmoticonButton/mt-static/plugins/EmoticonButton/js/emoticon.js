App.singletonConstructor =
MT.App = new Class( MT.App, {
    initEditor: function() {
        if ( this.constructor.Editor && DOM.getElement( "editor-content" ) ) {
            
            var mode = DOM.getElement( "convert_breaks" );
            DOM.addEventListener( mode, "change", this.getIndirectEventListener( "setTextareaMode" ) );
        
            /* special case */
            window.cur_text_format = mode.value;
        
            this.editorMode = ( mode.value == "richtext" ) ? "iframe" : "textarea";
            
            this.editor = this.addComponent( new MT.App.Editor.Emoticon( "editor-content", this.editorMode ) );
            this.editor.textarea.setTextMode( mode.value );
            this.editor.emoticon = this.addComponent( new MT.App.Emoticon( "emoticon", "emoticon" ) );
        
            this.editorInput = {
                content: DOM.getElement( "editor-input-content" ),
                extended: DOM.getElement( "editor-input-extended" )
            };
        
            if ( this.editorInput.content.value )
                this.editor.setHTML( this.editorInput.content.value );
        }
    }
});

MT.App.Emoticon = new Class( Transient, {

    initObject: function( element, templateName ) {
        arguments.callee.applySuper( this, arguments );
        this.templateName = templateName;
       
        this.contentElement = DOM.getElement( this.element.id + '-content' );
        if( !this.contentElement )
            this.contentElement = this.element;
        this.icons = this.populateIcons();
    },

    open: function() {
        arguments.callee.applySuper( this, arguments );
        this.render();
        this.reflow();
    },

    render: function() {
        this.contentElement.innerHTML = Template.process( "emoticons", { "icons": this.icons } ); 
    },

    eventClick: function( event ) {
        var id = event.target.id;
        var name = id.replace(/emoticon\-icon\-(\w+)/, '$1');
        if (!name || ( name == id ))
            return;
        var ancestor = DOM.getFirstAncestorByClassName( event.target, "emoticon-icon", true );
        if ( ancestor )
            DOM._rCN( ancestor, "hover-over" );
        if ( event.shiftKey )
            app.editor.toolbar.insertEmoticon({ 'name': name });
        else
            this.close( { 'name': name } );
    },

    eventMouseOver: function( event ) {
        var ancestor = DOM.getFirstAncestorByClassName( event.target, "emoticon-icon", true );
        if ( !ancestor )
            return;
        DOM._aCN( ancestor, "hover-over" );
    },

    eventMouseOut: function( event ) {
        var ancestor = DOM.getFirstAncestorByClassName( event.target, "emoticon-icon", true );
        if ( !ancestor )
            return;
        DOM._rCN( ancestor, "hover-over" );
    },

    populateIcons: function() {
        return [
            'sun','cloud','rain','snow','thunder','typhoon','mist','sprinkle','aries','taurus',
            'gemini','cancer','leo','virgo','libra','scorpius','sagittarius','capricornus','aquarius','pisces',
            'sports','baseball','golf','tennis','soccer','ski','basketball','motorsports','pocketbell','train',
            'subway','bullettrain','car','rvcar','bus','ship','airplane','house','building','postoffice',
            'hospital','bank','atm','hotel','24hours','gasstation','parking','signaler','toilet','restaurant',
            'cafe','bar','beer','fastfood','boutique','hairsalon','karaoke','movie','upwardright','carouselpony',
            'music','art','drama','event','ticket','smoking','nosmoking','camera','bag','book',
            'ribbon','present','birthday','telephone','mobilephone','memo','tv','game','cd','heart',
            'spade','diamond','club','eye','ear','rock','scissors','paper','downwardright','upwardleft',
            'foot','shoe','eyeglass','wheelchair','newmoon','moon1','moon2','moon3','fullmoon','dog',
            'cat','yacht','xmas','downwardleft','phoneto','mailto','faxto','info01','info02','mail',
            'by-d','d-point','yen','free','id','key','enter','clear','search','new',
            'flag','freedial','sharp','mobaq','one','two','three','four','five','six',
            'seven','eight','nine','zero','ok','heart01','heart02','heart03','heart04','happy01',
            'angry','despair','sad','wobbly','up','note','spa','cute','kissmark','shine',
            'flair','annoy','punch','bomb','notes','down','sleepy','sign01','sign02','sign03',
            'impact','sweat01','sweat02','dash','sign04','sign05','slate','pouch','pen','shadow',
            'chair','night','soon','on','end','clock','appli01','appli02','t-shirt','moneybag',
            'rouge','denim','snowboard','bell','door','dollar','pc','loveletter','wrench','pencil',
            'crown','ring','sandclock','bicycle','japanesetea','watch','think','confident','coldsweats01','coldsweats02',
            'pout','gawk','lovely','good','bleah','wink','happy02','bearing','catface','crying',
            'weep','ng','clip','copyright','tm','run','secret','recycle','r-mark','danger',
            'ban','empty','pass','full','leftright','updown','school','wave','fuji','clover',
            'cherry','tulip','banana','apple','bud','maple','cherryblossom','riceball','cake','bottle',
            'noodle','bread','snail','chick','penguin','fish','delicious','smile','horse','pig',
            'wine','shock'
        ];
    }
} );

MT.App.Editor.Emoticon = new Class( MT.App.Editor, {

} );

MT.App.Editor.Emoticon.Textarea = new Class( MT.App.Editor.Textarea, {

} );

MT.App.Editor.Emoticon.Iframe = new Class( MT.App.Editor.Iframe, {

} );

MT.App.Editor.Emoticon.Toolbar = new Class( MT.App.Editor.Toolbar, {
        
    insertEmoticon: function( data ) {
        if (!data) return;
        var name = data['name'];
        if (!name) return;
        this.editor.insertHTML('<img class="emoticon ' + name + '" src="' + StaticURI + 'plugins/EmoticonButton/images/emoticons/' + name + '.gif" alt="' + name + '" style="border:0;" />');
    },

    eventClick: function( event ) {
        var command = this.getMouseEventCommand( event );
        if ( !command )
            return event.stop();

        switch( command ) {

            case "openEmoticonPallet":
                this.editor.emoticon.open( null, this._gIM('insertEmoticon'), event.commandElement );
                break;

            default:
                return arguments.callee.applySuper( this, arguments );
        
        }

        return event.stop();
    }
});
