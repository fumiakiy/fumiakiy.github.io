package EmoticonButton::Plugin;

use strict;

sub inject_button_src {
	my ( $cb, $app, $tmpl) = @_;

	my $button = qq{<a href="javascript: void 0;" title="<__trans phrase="Emoticons" escape="html">" class="command-emoticon toolbar button" mt:command="open-emoticon-pallet" style="background-image:url('<mt:var name="static_uri">plugins/EmoticonButton/images/ed_emoticon.gif');background-position:center"><b>:)</b><s></s></a>};
	$$tmpl =~ s/(<a.+?class=".*?command-toggle-wysiwyg)/$button\n$1/;
	1;
}

sub inject_button_param {
	my ( $cb, $app, $param, $tmpl ) = @_;

	my $footer = $tmpl->getElementById('footer_include');
	if ( $footer ) {
		my $plugin = $cb->plugin;
		require File::Spec;
	    my $tmpl_path = File::Spec->catdir($plugin->path, 'tmpl', 'emoticon.tmpl');
		my $include = $tmpl->createElement('include', { name => $tmpl_path });
		$tmpl->insertBefore($include, $footer);
	}
	1;
}

sub emoticon_tag {
    return '' unless $_[0];
    return '[E:' . $_[0] . ']';
}

sub entry_loaded {
    my ( $cb, $entry ) = @_;

    return 1
        unless UNIVERSAL::isa( MT->instance, 'MT::AtomServer' );
    my $ua = $ENV{HTTP_USER_AGENT}
        or return 1;
    return 1
        unless $ua =~ m!TypeCast/!;

    my $text = $entry->text;
    my $text_more = $entry->text_more;

    # replace emoticons with TypeCast Emoticon Tag
    $text =~ s{<img [^>]*?class="emoticon ([\w\-]+)".*?/>}{emoticon_tag($1) || $&}eg;
    $text_more =~ s{<img [^>]*?class="emoticon ([\w\-]+)".*?/>}{emoticon_tag($1) || $&}eg;

    $entry->text($text);
    $entry->text_more($text_more);

    ## No, no, I am not updating these columns... :P
    delete $entry->{changed_cols}->{text};
    delete $entry->{changed_cols}->{text_more};
    1;
}

1;
