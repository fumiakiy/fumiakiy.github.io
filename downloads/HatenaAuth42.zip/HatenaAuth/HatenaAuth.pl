# HatenaAuth plugin for Movable Type
# Author: Fumiaki Yoshimatsu (http://www.luckypines.com/mt/)
# Released under the Artistic License

package MT::Plugin::HatenaAuth;

use strict;
use warnings;

use MT;
use MT::Util qw( is_url decode_url );
use base qw(MT::Plugin);

my $plugin = MT::Plugin::HatenaAuth->new({
    name => "Commenter Authrntication by Hateha ID",
    version => '0.1',
    description => "<MT_TRANS phrase=\"You can allow readers to authenticate themselves via Hatena ID to comment on posts.\">",
    author_name => "Fumiaki Yoshimatsu",
    author_link => "http://www.luckypines.com/mt/",
    settings => new MT::PluginSettings([
        ['hatena_api_key'],
        ['hatena_private_key'],
    ]),
	blog_config_template => <<TMPL,
<dl>
<dt>Your Hatena API Key</dt>
<dd><input name="hatena_api_key" size="40" value="<mt:var name="hatena_api_key">" /></dd>
<dt>Your Hatena API Private Key</dt>
<dd><input name="hatena_private_key" size="40" value="<mt:var name="hatena_private_key">" /></dd>
</dl>
TMPL
});
MT->add_plugin($plugin);

sub init_registry {
    my $plugin = shift;
    $plugin->registry({
        'commenter_authenticators' => {
            'hatenaid' => {
                label => 'Hatena ID',
                class => 'HatenaID',
                login_form => <<EOT,
<p><a href="<mt:var name="url">">Click here</a> to sign in via your Hatena ID.</p>
EOT
                login_form_params => sub {
                    my ($key, $blog_id, $entry_id, $static) = @_;

                    my %param;
                    $plugin->load_config(\%param, "blog:$blog_id");
                    my $api_key = $param{hatena_api_key};
                    my $private_key = $param{hatena_private_key};
                    
                    my $d_static = decode_url( $static );
                    my $args = {
                        api_key => $api_key,
                        __mode => 'handle_sign_in',
                        blog_id => $blog_id,
                        entry_id => $entry_id,
                        key => 'hatenaid',
                        is_url($d_static) ? 
                            ( static => $d_static )
                            : ( static => $static ),
                    };
                    my $api_sig = api_sig($args, $private_key);
                    my $url = "http://auth.hatena.ne.jp/auth?api_sig=$api_sig&";
                    $url .= join '&', map { $_ . '=' . $args->{$_} } keys %$args;
                    $param{url} = $url;
                    return \%param;
                },
            },
        },
    });
}

sub instance { $plugin }

## Duplicated from Hatena::API::Auth module
## http://search.cpan.org/~naoya/Hatena-API-Auth/
sub api_sig {
    my ($args, $sig) = @_;
    for my $key (sort {$a cmp $b} keys %{$args}) {
        my $value = $args->{$key} ? $args->{$key} : '';
        $sig .= $key . $value;
    }
    require Digest::MD5;
    return Digest::MD5::md5_hex($sig);
}

1;
