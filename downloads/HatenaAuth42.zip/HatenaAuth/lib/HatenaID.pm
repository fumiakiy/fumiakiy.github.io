package HatenaID;
use strict;
use JSON;
use HTTP::Request;
use Digest::MD5;

use base qw(MT::ErrorHandler);

sub handle_sign_in {
    my $class = shift;
    my ($app, $auth_type) = @_;
    my $q = $app->{query};

    my $blog_id = $q->param('blog_id');
    my $cert = $q->param('cert');

    my $plugin = MT::Plugin::HatenaAuth->instance;
    my $config = $plugin->get_config_hash("blog:$blog_id");
    my $api_key = $config->{hatena_api_key};
    my $private_key = $config->{hatena_private_key};

    my $sigval = $private_key . 'api_key' . $api_key . 'cert' . $cert;
    my $api_sig = Digest::MD5::md5_hex($sigval);
    my $url = "http://auth.hatena.ne.jp/api/auth.json?api_key=$api_key&cert=$cert&api_sig=$api_sig";

    my $ua = $app->new_ua;
    my $req = HTTP::Request->new( GET => $url );
    my $res = $ua->request($req);

    my $s = $res->content;
    $s =~ s/\\u([0-9a-fA-F]+)/&#x$1;/g;
    my $user;
    eval {
        $user= JSON::jsonToObj($s);
    };
    if ($@) {
        return $app->eror($@);
    }

    if ( $user->{has_error} ) {
        return $app->error($user->{error}{message});
    }
    my $name = $user->{user}{name};
    my $thumb = $user->{user}{thumbnail_url};
    my $user_url = "http://d.hatena.ne.jp/$name";

    my $cmntr;

    $cmntr = $app->_make_commenter(
        email     => q(),
        nickname  => "id:$name",
        name      => "id:$name",
        url       => $user_url,
        auth_type => 'Hatena',
    );
    unless ($cmntr) {
        return 0;
    }
    my $session = $app->make_commenter_session($cmntr);
    unless ($session) {
        $app->error($app->errstr() || $app->translate("Couldn't save the session"));
        return 0;
    }
    return $cmntr;
}

1;
