# MTHatenaStar plugin for Movable Type
# Author: Fumiaki Yoshimatsu (http://www.luckypines.com/mt/)
# Released under the Artistic License

package MT::Plugin::MTHatenaStar;

use strict;
use warnings;

use base qw(MT::Plugin);

my $plugin = MT::Plugin::MTHatenaStar->new({
    description => 'Template tag to inject some HTML template required to show Hatena Star',
    name => 'MTHatenaStar',
    author_name => 'Fumiaki Yoshimatsu',
    author_link => 'http://www.luckypines.com/mt/2007/08/mthatenastar.html',
	blog_config_template => <<TMPL,
<dl>
<dt>Your Hatena Star token<dt>
<dd><input name="hatenastar_token" size="40" value="<mt:var name="hatenastar_token">" /></dd>
</dl>
TMPL
    settings => new MT::PluginSettings([
        ['hatenastar_token'],
    ]),
    version => '0.1',
});

MT->add_plugin($plugin);
sub instance { $plugin }

sub init_registry {
    my $plugin = shift;
    $plugin->registry({
        tags => {
            function => {
                HatenaStarScript => \&_hdlr_hatena_star_script,
                HatenaStar => \&_hdlr_hatena_star,
            },
        },
    });
}

sub _hdlr_hatena_star_script {
    my ($ctx, $args) = @_;

    my $entry = $ctx->stash('entry');
    my $blog_id;
    if ($entry) {
        $blog_id = $entry->blog_id;
    }
    else {
        $blog_id = $ctx->stash('blog_id') || $ctx->var('blog_id');
    }
    return q() unless $blog_id;
    my $config = $plugin->get_config_hash("blog:$blog_id");
    return q() unless $config;
    my $token = $config->{hatenastar_token};
    return q() unless $token;

    $ctx->stash('hatena_star_script', 1);
    return <<EOT;
<script type="text/javascript" src="http://s.hatena.ne.jp/js/HatenaStar.js"></script>
<script type="text/javascript">
Hatena.Star.Token = '$token';
Hatena.Star.EntryLoader.headerTagAndClassName = ['span', 'hatenastar'];
</script>
EOT
}

sub _hdlr_hatena_star {
    my ($ctx, $args) = @_;

    my $ret = q();
    unless ( $ctx->stash('hatena_star_script') ) {
        $ret .= _hdlr_hatena_star_script(@_);
        $ctx->stash('hatena_star_script', 1);
    }

    my $entry = $ctx->stash('entry');
    return $ctx->error(MT->translate(
        "You used an '[_1]' tag outside of the context of an entry; " .
        "perhaps you mistakenly placed it outside of an 'MTEntries' container?",
        'MTHatenaStar')) unless $entry;

    my $entry_link = $entry->permalink;
    my $entry_title = $entry->title;
    $ret .= <<EOT;
<span class="hatenastar"><a href="$entry_link" style="display:none">$entry_title</a></span>
EOT
    $ret;
}

1;

