<?php
function smarty_function_mthatenastar($args, &$ctx) {
    $ret = '';
    if (!( $ctx->stash('hatena_star_script') ) ) {
        require_once('function.mthatenastarscript.php');
        $ret .= smarty_function_mthatenastarscript($args, $ctx);
        if (!$ret) {
            return '';
        }
    }
    $entry = $ctx->stash('entry');
    $entry_title = $entry['entry_title'];
    require_once('function.mtentrypermalink.php');
    $entry_link = smarty_function_mtentrypermalink($args, $ctx);
    $ret .= "<span class=\"hatenastar\"><a href=\"$entry_link\" style=\"display:none\">$entry_title</a></span>";
    return $ret;
}
?>
