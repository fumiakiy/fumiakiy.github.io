<?php
function smarty_function_mthatenastarscript($args, &$ctx) {
    $entry = $ctx->stash('entry');
    $blog_id = '';
    if ($entry) {
        $blog_id = $entry['entry_blog_id'];
    }
    else {
        $blog_id = $ctx->stash('blog_id') || $ctx->var('blog_id');
    }
    if (!$blog_id) {
        return '';
    }
    $config = $ctx->mt->db->fetch_plugin_config('MTHatenaStar', "blog:$blog_id");
    if ($config) {
        $token = $config['hatenastar_token'];
    }
    if (!$token) {
        return '';
    }

    $ctx->stash('hatena_star_script', 1);
    $ret = "
<script type=\"text/javascript\" src=\"http://s.hatena.ne.jp/js/HatenaStar.js\"></script>
<script type=\"text/javascript\">
Hatena.Star.Token = '$token';
Hatena.Star.EntryLoader.headerTagAndClassName = ['span', 'hatenastar'];
</script>";
    return $ret;
}
?>

